/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   pipex.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fde-alen <fde-alen@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/03/29 18:22:00 by mcombeau          #+#    #+#             */
/*   Updated: 2023/12/14 21:19:37 by fde-alen         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "pipex.h"

/* redirect_io:
*	Redirects the input and output file descriptors by duplicating
*	the given fds to the standard input and standard output respectively.
*/
static void	redirect_io(int input, int output, t_pipex_data *d)
{
	if (dup2(input, STDIN_FILENO) == -1)
	{
		exit_error(1, d);
	}
	if (dup2(output, STDOUT_FILENO) == -1)
	{
		exit_error(1, d);
	}
}

/* child:
*	Sets the child process's inputs and outputs depending on if it is
*	the first, middle or final child.
*	Then it parses the command it needs to execute and executes it.
*/
static void	child(t_pipex_data *data)
{
	if (data->child == 0)
		redirect_io(data->fd_in, data->pipe[1], data);
	else if (data->child == data->nb_cmds - 1)
		redirect_io(data->pipe[2 * data->child - 2], data->fd_out, data);
	else
		redirect_io(data->pipe[2 * data->child - 2], data->pipe[2 * data->child + 1], data);
	close_fds(data);
	if (data->cmd_options == NULL || data->cmd_path == NULL)
		exit_error(1, data);
	if (execve(data->cmd_path, data->cmd_options, data->envp) == -1)
		exit_error(msg(data->cmd_options[0], ": ", strerror(errno), 1), data);
}

/* parent:
*	Waits for the children processes to finish and fetches the status of the last
*	child.
*	Returns the exit status code of the last child process.
*/
static int	parent(t_pipex_data *data)
{
	pid_t	wpid;
	int		status;
	int		exit_code;

	close_fds(data);
	data->childata--;
	exit_code = 1;
	while (data->child >= 0)
	{
		wpid = waitpid(data->pids[data->child], &status, 0);
		if (wpid == data->pids[data->nb_cmds - 1])
		{
			if ((data->child == (data->nb_cmds - 1)) && WIFEXITED(status))
				exit_code = WEXITSTATUS(status);
		}
		data->childata--;
	}
	free(data->pipe);
	free(data->pids);
	return (exit_code);
}

/* pipex:
*	Creates a pipe and forks all necessary child processes before calling
*	the parent to wait for them to finish their tasks.
*	Returns: the last child's exit code.
*/
static int	pipex(t_pipex_data *data)
{
	int		exit_code;

	if (pipe(data->pipe) == -1)
		exit_error(msg("pipe", ": ", strerror(errno), 1), data);
	data->child = 0;
	while (data->child < data->nb_cmds)
	{
		data->cmd_options = ft_split(data->av[data->child + 2 + data->heredoc], ' ');
		if (!data->cmd_options)
			exit_error(msg("unexpected error", "", "", 1), data);
		data->cmd_path = get_cmd(data->cmd_options[0], data);
		data->pids[data->child] = fork();
		if (data->pids[data->child] == -1)
			exit_error(msg("fork", ": ", strerror(errno), 1), data);
		else if (data->pids[data->child] == 0)
			child(data);
		free_strs(data->cmd_path, data->cmd_options);
		data->child++;
	}
	exit_code = parent(data);
	if (data->heredoc == 1)
		unlink(".heredoc.tmp");
	return (exit_code);
}

/* main:
*	Launches d structure initialization and starts pipex.
*	Returns the last child's exit code as pipex's exit code.
*/
int	main(int ac, char **av, char **envp)
{
	t_pipex_data	d;
	int		exit_code;

	if (ac < 5)
	{
		if (ac >= 2 && !ft_strncmp("here_doc", av[1], 9))
			return (msg("Usage: ",
					"./pipex here_doc LIMITER cmd1 cmd2 ... cmdn file2.",
					"", 1));
		return (msg("Usage: ",
				"./pipex file1 cmd1 cmd2 ... cmdn file2.", "", 1));
	}
	else if (ac < 6 && !ft_strncmp("here_doc", av[1], 9))
		return (msg("Usage: ",
				"./pipex here_doc LIMITER cmd1 cmd2 ... cmdn file2.", "", 1));
	if (!envp || envp[0][0] == '\0')
		exit_error(msg("Unexpected error.", "", "", 1), &d);
	d = init(ac, av, envp);
	exit_code = pipex(&d);
	return (exit_code);
}
