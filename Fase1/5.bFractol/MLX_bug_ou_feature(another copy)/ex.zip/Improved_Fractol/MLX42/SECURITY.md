# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.0.x   | ✅                 |
| 1.0.x   | ❌                 |

## Reporting a Vulnerability

For security issues please refrain from opening an issue!
Instead write an email to [w2.wizzard@gmail.com](mailto:w2.wizzard@gmail.com)
